**IDEA StatiCa for Python (ideastaticapy)**

ideastaticapy is a package for running common IDEA StatiCa commands build on top of the IDEA StatiCa C# API and Plugin.
