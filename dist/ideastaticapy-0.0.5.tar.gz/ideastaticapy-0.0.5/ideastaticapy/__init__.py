"""
@author: Steven Verwer
@git: https://github.com/stevenverwer
"""

from ideastaticapy import connection
from ideastaticapy import ideaConnection